   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
<<<<<<< HEAD
                   &copy; 2019 Online Library Management System | Designed By : ITP_GROUP_16 
=======
                   &copy; 2019 Online Library Management System |<a href="https://phpgurukul.com/" target="_blank"  > Designed by : ITP_Group_16</a> 
>>>>>>> 4185aa523a25502b0482b864bb9d9dd4d8541309
                </div>

            </div>
        </div>
    </section>